package com.example.apprawan;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class App extends AppCompatActivity {

    private Object Activity1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button B = findViewById(R.id.button);
        Button u = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        B.setText(R.string.about);
        u.setText(R.string.callus);
        button3.setText(R.string.exit);

    }

    public void About(View v) {
        startActivity(new Intent(this, App2.class));

    }

    public void CallUs(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:+966555555555"));
        startActivity(i);
    }
}






